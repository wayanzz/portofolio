 <!-- header start -->
 <header class="fixed-top bg-light header-top-area theme-bg top-space" style="box-shadow: 0px 0px 15px #00000054">
     <div class="header-bottom-area">
         <div class="container">
             <div class="row align-items-center">
                 <div class="col-xl-3 col-lg-3">
                     <div class="logo">
                         <a href="index.html">
                             <h3>Diva Reklame</h3>
                         </a>
                     </div>
                 </div>
                 <div class="col-xl-9 col-lg-9">
                     <div class="main-menu f-right">
                         <nav id="mobile-menu">
                             <ul>
                                 <li>
                                     <a href="<?php echo e(route('home.index')); ?>">Beranda</a>
                                 </li>
                                 <li><a href="<?php echo e(route('about.index')); ?>">Tentang</a></li>
                                 <li>
                                     <a href="<?php echo e(route('services.index')); ?>">Layanan</a>
                                 </li>
                                 <li>
                                     <a href="<?php echo e(route('contact.index')); ?>">Kontak</a>
                                 </li>
                                 <?php if(auth()->guard()->check()): ?>
                                     <li>
                                         <a href="<?php echo e(route('login')); ?>">Dashboard</a>
                                     </li>
                                 <?php endif; ?>
                                 <?php if(auth()->guard()->guest()): ?>
                                     <li>
                                         <a href="<?php echo e(route('login')); ?>">Masuk</a>
                                     </li>
                                     <li>
                                         <a href="<?php echo e(route('register')); ?>">Daftar</a>
                                     </li>
                                 <?php endif; ?>
                             </ul>
                         </nav>
                     </div>
                     <div class="mobile-menu"></div>
                 </div>
             </div>
         </div>
     </div>
 </header>
 <!-- header end -->
<?php /**PATH C:\Users\Wayan Bagus\Downloads\diva-reklame-laravel\resources\views/diva-reklame/partials/header.blade.php ENDPATH**/ ?>