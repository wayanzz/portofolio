<?php $__env->startSection('auth'); ?>
    <main class="main" id="top">
        <div class="container" data-layout="container">
            <div class="row flex-center min-vh-100 py-6 text-center">
                <div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4"><a class="d-flex flex-center mb-4"
                        href="<?php echo e(route('home.index')); ?>"><img class="me-2"
                            src="<?php echo e(asset('asset/assets/img/icons/spot-illustrations/falcon.png')); ?>" alt="Diva Reklame"
                            width="58" /><span class="font-sans-serif text-primary fw-bolder fs-5 d-inline-block">Diva
                            Reklame</span></a>
                    <div class="card">
                        <div class="card-body p-4 p-sm-5">
                            <h5 class="mb-0">Lupa kata sandi?</h5><small>Masukkan alamat email anda dan kami akan
                                mengirimkan link reset kata sandi.</small>
                            <form class="mt-4"><input class="form-control" type="email" placeholder="Alamat Email" />
                                <div class="mb-3"></div><button class="btn btn-primary d-block w-100 mt-3" type="submit"
                                    name="submit">Kirim link</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\infernux\Documents\diva-reklame-laravel\resources\views/auth/user/forgot-pasword.blade.php ENDPATH**/ ?>