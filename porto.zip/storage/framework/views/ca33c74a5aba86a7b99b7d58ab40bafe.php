<?php $__env->startSection('auth'); ?>
    <main class="main" id="top">
        <div class="container" data-layout="container">
            <div class="row flex-center min-vh-100 py-6">
                <div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4"><a class="d-flex flex-center mb-4"
                        href="<?php echo e(route('home.index')); ?>"><img class="me-2"
                            src="<?php echo e(asset('asset/assets/img/icons/spot-illustrations/falcon.png')); ?>" alt=""
                            width="58" /><span class="font-sans-serif text-primary fw-bolder fs-5 d-inline-block">Diva
                            Reklame</span></a>
                    <div class="card">
                        <div class="card-body p-4 p-sm-5">
                            <div class="row flex-between-center mb-2">
                                <div class="col-auto">
                                    <h5>Masuk</h5>
                                </div>
                                <div class="col-auto fs--1 text-600"><span class="mb-0 undefined">atau</span> <span><a
                                            href="<?php echo e(route('register')); ?>">Buat akun</a></span></div>
                            </div>
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3"><input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required name="email" type="email"
                                        placeholder="Alamat Email" /></div>
                                <div class="mb-3"><input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" type="password"
                                        placeholder="Kata Sandi" required /></div>
                                <div class="row flex-between-center">
                                    <div class="col-auto">
                                        <div class="form-check mb-0"><input class="form-check-input" type="checkbox"
                                                id="basic-checkbox" checked="checked" /><label class="form-check-label mb-0"
                                                for="basic-checkbox">Ingat Saya</label>
                                        </div>
                                    </div>
                                    <div class="col-auto"><a class="fs--1" href="<?php echo e(route('password.request')); ?>">Lupa
                                            Sandi?</a></div>
                                </div>
                                <div class="mb-3"><button class="btn btn-primary d-block w-100 mt-3" type="submit"
                                        name="submit">Masuk</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\infernux\Documents\diva-reklame-laravel\resources\views/auth/user/login.blade.php ENDPATH**/ ?>