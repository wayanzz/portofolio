<?php $__env->startSection('auth'); ?>
    <main class="main" id="top">
        <div class="container" data-layout="container">
            <div class="row flex-center min-vh-100 py-6">
                <div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4"><a class="d-flex flex-center mb-4"
                        href="<?php echo e(route('home.index')); ?>"><img class="me-2"
                            src="<?php echo e(asset('asset/assets/img/icons/spot-illustrations/falcon.png')); ?>" alt="Diva Reklame"
                            width="58" /><span class="font-sans-serif text-primary fw-bolder fs-5 d-inline-block">Diva
                            Reklame</span></a>
                    <div class="card">
                        <div class="card-body p-4 p-sm-5">
                            <div class="row flex-between-center mb-2">
                                <div class="col-auto">
                                    <h5>Daftar</h5>
                                </div>
                                <div class="col-auto fs--1 text-600"><span class="mb-0 undefined">Sudah memiliki
                                        akun?</span> <span><a href="<?php echo e(route('login')); ?>">Masuk</a></span></div>
                            </div>
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <input class="form-control" type="text" autocomplete="on" placeholder="Nama"
                                        name="nama" />
                                </div>
                                <div class="mb-3">
                                    <input class="form-control" type="email" autocomplete="on" placeholder="Alamat Email"
                                        name="email" />
                                </div>
                                <div class="row gx-2">
                                    <div class="mb-3 col-sm-6">
                                        <input class="form-control" type="password" autocomplete="on"
                                            placeholder="Kata Sandi" name="password" />
                                    </div>
                                    <div class="mb-3 col-sm-6">
                                        <input class="form-control" type="password" autocomplete="on"
                                            placeholder="Konfirmasi Kata Sandi" name="password_confirmation" />
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <input class="form-control" type="number" autocomplete="on" name="telepon"
                                        placeholder="Telepon" />
                                </div>
                                <div class="mb-3">
                                    <textarea name="alamat" class="form-control" autocomplete="on" placeholder="Alamat"></textarea>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="basic-register-checkbox" /><label
                                        class="form-label" for="basic-register-checkbox">Saya menyetujui kebijakan
                                        layanan</label>
                                </div>
                                <div class="mb-3"><button class="btn btn-primary d-block w-100 mt-3" type="submit"
                                        name="submit">Daftar</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\infernux\Documents\diva-reklame-laravel\resources\views/auth/user/register.blade.php ENDPATH**/ ?>