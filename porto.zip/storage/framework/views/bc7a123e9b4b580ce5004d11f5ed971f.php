<?php echo e($slot); ?>

<?php /**PATH C:\Users\Wayan Bagus\Downloads\diva-reklame-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>