<footer class="footer">
    <div class="row g-0 justify-content-between fs--1 mt-4 mb-3">
        <div class="col-12 col-sm-auto text-center">
            <p class="mb-0 text-600">Copyright &copy; <?php echo e(date('Y')); ?> <span class="d-none d-sm-inline-block">|
                </span><br class="d-sm-none" /> <a href="<?php echo e(route('home.index')); ?>">Diva Reklame</a></p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\infernux\Documents\diva-reklame-laravel\resources\views/dashboard/partials/footer.blade.php ENDPATH**/ ?>