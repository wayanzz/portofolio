<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Wayan Bagus\Downloads\diva-reklame-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>