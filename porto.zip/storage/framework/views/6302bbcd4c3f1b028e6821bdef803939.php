<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Diva Reklame - Beranda</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="#" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/linearicons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/default.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>" />
</head>

<body>

    <?php echo $__env->make('diva-reklame.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('diva-reklame.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('assets/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/jquery.meanmenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-js/bootstrap.main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\infernux\Documents\diva-reklame-laravel\resources\views/diva-reklame/partials/main.blade.php ENDPATH**/ ?>